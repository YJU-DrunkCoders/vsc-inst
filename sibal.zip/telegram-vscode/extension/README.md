## Features

Telegram for VSCode

## Usage

Use it from the sidebar

or

Open Command Palette with `CTRL`+`SHIFT`+`P` or `F1` and type `Open Telegram in a Tab`

## Known Issues
- No Audio playback

Every feedback would be appreciated
If you need help or have any question, feel free to ask at zangico@gmail.com

## Release Notes

### 1.0.0

Initial release

### 1.1.0

Added sidebar feature

### 1.2.0

No need for external script running anymore

### 1.2.1

Added Output Channel 'Telegram-VSCode'
Fixed BUG with proxy script not running...

### 1.2.2

Fix for the proxy script not running on macos