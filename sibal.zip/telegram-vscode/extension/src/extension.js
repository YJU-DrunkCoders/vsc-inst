const vscode = require('vscode');
const { execFile } = require('child_process');
const path = require('path');
const os = require('os');

const platform = os.platform();
let serverExecutable;

if (platform === 'win32') {
  serverExecutable = 'instagram-proxy-server-win.exe';
} else if (platform === 'darwin') {
  serverExecutable = 'instagram-proxy-server-macos';
} else if (platform === 'linux') {
  serverExecutable = 'instagram-proxy-server-linux';
} else {
  console.error(`Unsupported platform: ${platform}`);
  process.exit(1);
}

const serverPath = path.resolve(__dirname, 'binaries', serverExecutable);
const logger = vscode.window.createOutputChannel('Instagram-VSCode');

function activate(context) {
    // Start proxy server
    execFile(serverPath, (error, stdout, stderr) => {
        if (error) {
            logger.appendLine(`Error executing server: ${error.message}`);
            logger.appendLine(`stderr: ${stderr}`);
            return;
        }
        logger.appendLine(`Server output: ${stdout}`);
    });

    // Register command to open in tab
    context.subscriptions.push(
        vscode.commands.registerCommand('instagram-vscode.openInstagramWeb', () => {
            const panel = vscode.window.createWebviewPanel(
                'instagramWebviewTab',
                'Instagram',
                vscode.ViewColumn.One,
                {
                    enableScripts: true,
                    retainContextWhenHidden: true
                }
            );
            panel.webview.html = getWebviewContent();
        })
    );

    // Register sidebar view
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider('instagramWebview', {
            resolveWebviewView(webviewView, context, token) {
                webviewView.webview.options = {
                    enableScripts: true,
                    localResourceRoots: []
                };
                webviewView.webview.html = getWebviewContent();
                
                // Handle messages from the webview
                webviewView.webview.onDidReceiveMessage(message => {
                    if (message.type === 'error') {
                        logger.appendLine(`Instagram iframe error: ${message.text}`);
                    } else if (message.type === 'log') {
                        logger.appendLine(`Instagram iframe log: ${message.text}`);
                    }
                });
            }
        })
    );

    context.subscriptions.push(logger);
}

function getWebviewContent() {
    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="Content-Security-Policy" content="default-src * 'unsafe-inline' 'unsafe-eval'; img-src * data: blob: 'unsafe-inline'; frame-src *; connect-src *;">
            <title>Instagram Web</title>
            <style>
                body, html {
                    margin: 0;
                    padding: 0;
                    height: 100%;
                    width: 100%;
                    overflow: hidden;
                }
                iframe {
                    border: none;
                    height: 100%;
                    width: 100%;
                }
                .loading {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100%;
                    width: 100%;
                    position: absolute;
                    background: #ffffff;
                    z-index: 10;
                    transition: opacity 0.5s;
                }
                .loading.hidden {
                    opacity: 0;
                    z-index: -1;
                }
                .spinner {
                    width: 40px;
                    height: 40px;
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid #3498db;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        </head>
        <body>
            <div class="loading" id="loadingIndicator">
                <div class="spinner"></div>
            </div>
            <iframe 
                src="http://localhost:49153/" 
                id="instagramFrame"
                sandbox="allow-downloads allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts allow-storage-access-by-user-activation" 
                allow="camera; microphone; geolocation; clipboard-read; clipboard-write; fullscreen; encrypted-media; web-share" 
                onload="handleIframeLoad()" 
            ></iframe>
            <script>
                const vscode = acquireVsCodeApi();
                let loadAttempts = 0;
                const maxLoadAttempts = 3;
                
                // 프레임 로드 처리
                function handleIframeLoad() {
                    console.log('Instagram iframe loaded');
                    const iframe = document.getElementById('instagramFrame');
                    
                    // 로딩 인디케이터 숨기기
                    document.getElementById('loadingIndicator').classList.add('hidden');
                    
                    // 로그 메시지 전송
                    vscode.postMessage({ 
                        type: 'log',
                        text: 'Instagram iframe loaded'
                    });
                    
                    // iframe에 포커스
                    iframe.focus();
                    
                    // 스크립트 삽입 시도
                    try {
                        const frameDoc = iframe.contentDocument || iframe.contentWindow.document;
                        
                        // 프레임 내부에 스크립트 삽입
                        const script = frameDoc.createElement('script');
                        script.textContent = \`
                            // X-Frame-Options 무효화
                            if (window.top !== window.self) {
                                document.documentElement.style.display = 'block';
                            }
                            
                            // 링크 처리
                            document.addEventListener('click', function(e) {
                                if (e.target.tagName === 'A') {
                                    e.target.target = '_self';
                                }
                            }, true);
                        \`;
                        
                        frameDoc.head.appendChild(script);
                    } catch (e) {
                        console.log('Could not inject script into iframe:', e);
                        
                        // 에러 보고
                        vscode.postMessage({ 
                            type: 'error',
                            text: 'Script injection error: ' + e.message 
                        });
                        
                        loadAttempts++;
                        if (loadAttempts < maxLoadAttempts) {
                            // 페이지 다시 로드 시도
                            setTimeout(() => {
                                iframe.src = iframe.src;
                            }, 1000);
                        }
                    }
                }
                
                // 오류 처리
                window.addEventListener('error', event => {
                    vscode.postMessage({ 
                        type: 'error',
                        text: event.message 
                    });
                });
                
                // 메시지 수신
                window.addEventListener('message', event => {
                    console.log('Received message:', event.data);
                });
            </script>
        </body>
        </html>
    `;
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
};