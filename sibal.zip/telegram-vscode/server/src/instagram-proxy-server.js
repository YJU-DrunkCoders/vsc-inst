const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const cors = require('cors');
const session = require('express-session');
const axios = require('axios'); // 추가된 의존성 - npm install axios 설치 필요
const https = require('https');
const querystring = require('querystring');

const app = express();

// Session middleware
app.use(session({
  secret: 'instagram-vscode-secret',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

// Enable CORS
app.use(cors({
  origin: true,
  credentials: true
}));

// Parse cookies and body
app.use(cookieParser());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

// Store cookies in memory
let savedCookies = [];
let isLoggedIn = false;
let authCookies = {};

// Special route for debugging cookies
app.get('/debug/cookies', (req, res) => {
  res.json({
    savedCookies: savedCookies,
    authCookies: authCookies,
    requestCookies: req.headers.cookie || 'none',
    isLoggedIn: isLoggedIn
  });
});

// Instagram 메인 페이지 접속
app.get('/', (req, res) => {
  if (isLoggedIn) {
    return res.redirect('/feed');
  }

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Instagram in VS Code</title>
      <style>
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          background-color: #fafafa;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          margin: 0;
          padding: 20px;
          box-sizing: border-box;
        }
        .container {
          display: flex;
          flex-direction: column;
          align-items: center;
          max-width: 400px;
          width: 100%;
          background: white;
          border: 1px solid #dbdbdb;
          border-radius: 3px;
          padding: 30px;
          box-sizing: border-box;
        }
        .logo {
          margin-bottom: 20px;
          width: 175px;
        }
        .button {
          background-color: #0095f6;
          color: white;
          border: none;
          border-radius: 4px;
          padding: 8px 16px;
          font-weight: bold;
          width: 100%;
          cursor: pointer;
          margin-top: 20px;
        }
        .button:hover {
          background-color: #1877f2;
        }
        .note {
          margin-top: 20px;
          color: #8e8e8e;
          text-align: center;
          font-size: 14px;
        }
        .error {
          color: #ed4956;
          text-align: center;
          margin: 10px 0;
        }
        
        /* Login form styles */
        .form-group {
          width: 100%;
          margin-bottom: 15px;
        }
        input {
          width: 100%;
          padding: 10px;
          border: 1px solid #dbdbdb;
          border-radius: 3px;
          box-sizing: border-box;
          font-size: 14px;
        }
        .login-form {
          width: 100%;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <img class="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/Instagram_logo.png/800px-Instagram_logo.png" alt="Instagram" style="width:120px;">
        <h2>Instagram in VS Code</h2>
        <p>To use Instagram in VS Code, you need to log in with your Instagram credentials.</p>
        
        <div id="loginOptions">
          <!-- 직접 로그인 폼 -->
          <div class="login-form">
            <form id="directLoginForm" method="POST" action="/direct-login">
              <div class="form-group">
                <input type="text" name="username" placeholder="Username or Email" required>
              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
              </div>
              <button type="submit" class="button">Log In</button>
            </form>
            ${req.query.error ? '<div class="error">Login failed. Please try again.</div>' : ''}
          </div>
        </div>
        
        <div class="note">
          Once logged in, you'll be redirected back to view Instagram inside VS Code.
          <br><br>
          Note: Due to Instagram security measures, some functionality may be limited.
        </div>
      </div>
    </body>
    </html>
  `;
  res.send(html);
});

// Endpoint to check login status
app.get('/check-login-status', (req, res) => {
  res.json({ loggedIn: isLoggedIn });
});

// 직접 로그인 처리
app.post('/direct-login', async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.redirect('/?error=missing_credentials');
  }

  console.log(`직접 로그인 시도: ${username}`);
  
  try {
    // 1. Instagram CSRFToken 획득을 위한 기본 페이지 요청
    const baseUrlResponse = await axios.get('https://www.instagram.com/', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5'
      },
      httpsAgent: new https.Agent({  
        rejectUnauthorized: false
      })
    });

    // CSRFToken 및 쿠키 추출
    let csrftoken = '';
    const cookies = {};
    
    if (baseUrlResponse.headers['set-cookie']) {
      baseUrlResponse.headers['set-cookie'].forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [cookieName, cookieValue] = cookiePair.split('=');
        
        cookies[cookieName] = cookieValue;
        
        if (cookieName === 'csrftoken') {
          csrftoken = cookieValue;
        }
        
        // 쿠키 저장
        if (!savedCookies.includes(cookiePair)) {
          savedCookies.push(cookiePair);
        }
      });
    }
    
    console.log('초기 CSRFToken:', csrftoken);
    
    if (!csrftoken) {
      console.error('CSRFToken을 얻지 못했습니다.');
      return res.redirect('/?error=csrf_token_missing');
    }

    // 2. 로그인 요청
    const loginFormData = querystring.stringify({
      username: username,
      enc_password: `#PWD_INSTAGRAM_BROWSER:0:${Math.floor(Date.now() / 1000)}:${password}`,
      queryParams: '{}',
      optIntoOneTap: 'false'
    });

    // 쿠키 문자열 생성
    const cookieString = Object.entries(cookies)
      .map(([name, value]) => `${name}=${value}`)
      .join('; ');

    console.log('로그인 요청 전송...');
    
    const loginResponse = await axios.post('https://www.instagram.com/accounts/login/ajax/', loginFormData, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-CSRFToken': csrftoken,
        'X-Instagram-AJAX': '1',
        'X-Requested-With': 'XMLHttpRequest',
        'Cookie': cookieString,
        'Referer': 'https://www.instagram.com/',
        'Origin': 'https://www.instagram.com'
      },
      withCredentials: true,
      httpsAgent: new https.Agent({  
        rejectUnauthorized: false
      })
    });

    console.log('로그인 응답:', loginResponse.data);
    
    // 로그인 성공 확인
    if (loginResponse.data.authenticated === true) {
      console.log('로그인 성공!');
      isLoggedIn = true;
      
      // 로그인 응답에서 쿠키 저장
      if (loginResponse.headers['set-cookie']) {
        loginResponse.headers['set-cookie'].forEach(cookie => {
          const [cookiePair] = cookie.split(';');
          if (!savedCookies.includes(cookiePair)) {
            savedCookies.push(cookiePair);
          }
        });
      }
      
      // 인증 쿠키 저장
      authCookies = {
        ...cookies,
        sessionid: loginResponse.data.sessionid
      };
      
      return res.redirect('/feed');
    } else {
      console.log('로그인 실패:', loginResponse.data);
      return res.redirect('/?error=authentication_failed');
    }
  } catch (error) {
    console.error('로그인 요청 오류:', error.message);
    if (error.response) {
      console.error('응답 데이터:', error.response.data);
      console.error('응답 상태:', error.response.status);
      console.error('응답 헤더:', error.response.headers);
    }
    return res.redirect('/?error=request_error');
  }
});

// Feed 페이지
app.get('/feed', (req, res) => {
  if (!isLoggedIn) {
    return res.redirect('/');
  }

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Instagram Feed</title>
      <style>
        body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; }
        iframe { border: none; width: 100%; height: 100%; }
        .message {
          position: fixed;
          top: 10px;
          left: 0;
          right: 0;
          text-align: center;
          background: rgba(0,0,0,0.7);
          color: white;
          padding: 10px;
          z-index: 1000;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }
      </style>
    </head>
    <body>
      <div class="message">Instagram Embed - VS Code Extension</div>
      <iframe src="https://www.instagram.com/" frameborder="0" allowfullscreen></iframe>
      
      <script>
        // Set the cookies for the iframe
        document.addEventListener('DOMContentLoaded', function() {
          fetch('/get-cookies')
            .then(response => response.json())
            .then(data => {
              console.log('Retrieved cookies');
              
              // Set cookies in iframe
              const iframe = document.querySelector('iframe');
              iframe.onload = function() {
                try {
                  // This might fail due to same-origin policy
                  Array.from(data.cookies || []).forEach(cookie => {
                    iframe.contentWindow.document.cookie = cookie;
                  });
                } catch (e) {
                  console.error('Failed to set cookies in iframe:', e);
                }
              };
            })
            .catch(error => console.error('Error getting cookies:', error));
        });
      </script>
    </body>
    </html>
  `;
  res.send(html);
});

// API 쿠키 획득
app.get('/get-cookies', (req, res) => {
  res.json({ cookies: savedCookies });
});

// 로그아웃
app.get('/logout', (req, res) => {
  savedCookies = [];
  authCookies = {};
  isLoggedIn = false;
  res.redirect('/');
});

// Instagram 프록시 미들웨어
const instagramProxy = createProxyMiddleware({
  target: 'https://www.instagram.com',
  changeOrigin: true,
  secure: false,
  followRedirects: true,
  logLevel: 'debug',
  selfHandleResponse: false,
  onProxyReq: (proxyReq, req, res) => {
    // 쿠키 설정
    if (savedCookies.length > 0) {
      const cookieString = savedCookies.join('; ');
      proxyReq.setHeader('Cookie', cookieString);
    }
    
    // 헤더 설정
    proxyReq.setHeader('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36');
    proxyReq.setHeader('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8');
    proxyReq.setHeader('Accept-Language', 'en-US,en;q=0.5');
    proxyReq.setHeader('X-Instagram-AJAX', '1');
    proxyReq.setHeader('X-IG-App-ID', '936619743392459');
    
    console.log(`프록시 요청: ${req.method} ${req.url}`);
  },
  onProxyRes: (proxyRes, req, res) => {
    // 보안 헤더 제거
    delete proxyRes.headers['x-frame-options'];
    delete proxyRes.headers['content-security-policy'];
    
    // 쿠키 수집
    if (proxyRes.headers['set-cookie']) {
      proxyRes.headers['set-cookie'].forEach(cookie => {
        const cookiePair = cookie.split(';')[0];
        if (!savedCookies.includes(cookiePair)) {
          savedCookies.push(cookiePair);
        }
      });
    }
    
    console.log(`프록시 응답: ${proxyRes.statusCode} for ${req.url}`);
  },
  onError: (err, req, res) => {
    console.error('프록시 오류:', err);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Proxy error: ' + err.message);
  }
});

// 프록시 적용
app.use('/instagram', instagramProxy);

// 서버 시작
app.listen(49153, () => {
  console.log('Instagram proxy server is running on http://localhost:49153');
  console.log('DEBUG: Access http://localhost:49153/debug/cookies to see stored cookies');
});